Para la creacion de los html de Inicio, Libros y reservas no se ha usado ayuda externa.
Para CSS y js se ha utilizado ayuda de ChatGPT  para agilizar sobretodo la parte de CSS y gitHub.
https://github.com/jjchinchi/juego-ahorcado
https://codigojavascript.online/juego-del-ahorcado-en-javascript/
https://platzi.com/clases/39-programacion-basica-2014/1849-creando-el-juego-del-ahorcado/
https://developergarcia.wordpress.com/2019/02/12/juego-el-ahorcado-codigo/
En el js de ahorcado base se le han añadido varias funcionalidades extra entre las que se encuentran
el div que muestra pistas sobre las palabras a adivinar y el mostrar palabras usadas.